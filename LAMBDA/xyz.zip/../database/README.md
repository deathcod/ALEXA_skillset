# THINGS TO KNOW  
http://docs.aws.amazon.com/amazondynamodb/latest/gettingstartedguide/GettingStarted.Python.html

Scan  
http://docs.aws.amazon.com/amazondynamodb/latest/APIReference/API_Scan.html

DynamoDb conditions  
http://boto3.readthedocs.io/en/latest/reference/customizations/dynamodb.html#ref-dynamodb-conditions

Hash key and range key difference  
https://stackoverflow.com/questions/27329461/what-is-hash-and-range-primary-key